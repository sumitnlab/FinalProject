package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Service
@javax.transaction.Transactional
public class UserService {

@Autowired
private  UserRepository repo;
	
//	public UserService(UserRepository userRepository) {
//		this.userRepository=userRepository;
//	}
	public UserService() {}
	
	public UserService(UserRepository repo) {
		super();
		this.repo = repo;
		
	}
	
	public void saveMyUser(User user ) {
		repo.save(user);
	}
}
