package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooklibdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooklibdemoApplication.class, args);
	}

}
