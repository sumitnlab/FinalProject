package com.example.demo.booklib.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.booklib.dto.books;
import com.example.demo.booklib.repository.BookRepository;
import com.example.demo.booklib.service.bookservice;

@RestController
@CrossOrigin

public class bookcontroller {
			
		@Autowired
		private bookservice bookservice;

		// fetch all books data
		@RequestMapping("/AllBooks")
		public List<books> getAllBookings() {
			return bookservice.getAllBooks();
		}

	
		
		// fetch specific data based on Book name
		@RequestMapping(value = "/BookName/{name}", method = RequestMethod.GET)
		@ResponseBody
		public List<books> findBooksName(@PathVariable String name) {
			List<books> BookResponse = (List<books>) bookservice.findByName(name);
			return BookResponse;
		}
		
		
		
		// fetch specific data based on author name
		@RequestMapping(value = "/BookAuthor/{authorname}", method = RequestMethod.GET)
		@ResponseBody
		public List<books> findBooksUsingAuthorName(@PathVariable String authorname) {
			List<books> BookResponse = (List<books>) bookservice.findByAuthor(authorname);
			return BookResponse;
		}
		
		
		
}
