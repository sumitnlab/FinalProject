package com.example.demo.booklib.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Books")
public class books {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	private String authorname;
	private int price;
	private String image;
	private String discription;
	private String pdf;
	private int rentprice;
	

	public books() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public books(int id, String name, String authorname, int price, String image, String discription, String pdf,
			int rentprice) {
		super();
		this.id = id;
		this.name = name;
		this.authorname = authorname;
		this.price = price;
		this.image = image;
		this.discription = discription;
		this.pdf = pdf;
		this.rentprice = rentprice;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getAuthorname() {
		return authorname;
	}



	public void setAuthorname(String authorname) {
		this.authorname = authorname;
	}



	public int getPrice() {
		return price;
	}



	public void setPrice(int price) {
		this.price = price;
	}



	public String getImage() {
		return image;
	}



	public void setImage(String image) {
		this.image = image;
	}



	public String getDiscription() {
		return discription;
	}



	public void setDiscription(String discription) {
		this.discription = discription;
	}



	public String getPdf() {
		return pdf;
	}



	public void setPdf(String pdf) {
		this.pdf = pdf;
	}



	public int getRentprice() {
		return rentprice;
	}



	public void setRentprice(int rentprice) {
		this.rentprice = rentprice;
	}



	@Override
	public String toString() {
		return "books [id=" + id + ", name=" + name + ", authorname=" + authorname + ", price=" + price + ", image="
				+ image + ", discription=" + discription + ", pdf=" + pdf + ", rentprice=" + rentprice + "]";
	}
	
	

	


}
