package com.example.demo.booklib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.booklib.dto.books;

import java.util.List;


@Repository
public interface BookRepository extends CrudRepository<books, Long>{


	@Query("SELECT b FROM books b WHERE b.authorname LIKE %?1%")   
	public List<books> findByAuthor(String authorname);
	
	@Query("SELECT p FROM books p WHERE p.name LIKE %?1%")   
	public List<books> findByname(String name);
	
}
