package com.example.demo.booklib.service;

import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.booklib.dto.books;
import com.example.demo.booklib.repository.BookRepository;

@Service
@javax.transaction.Transactional
public class bookservice {
	
	@Autowired
	private BookRepository bookrepository;

	//fetch data 
	
	public List<books> getAllBooks() 
	{
		List<books> bookings = new ArrayList<books>();
		bookrepository.findAll().forEach(bookings :: add);
		return bookings;
	}	

	
	public List<books> findByName(String name) {

        var Book1 = (List<books>) bookrepository.findByname(name);
        return Book1;
    }


    public List<books> findByAuthor(String authorname) {

        var Book = (List<books>) bookrepository.findByAuthor(authorname);
        return Book;
    }
	
	 
}
